package com.cg.appl.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringUtil {

	private ApplicationContext context;
	
	public SpringUtil(){
		
		context = new ClassPathXmlApplicationContext("companyHr.xml");
		
	}
	
	public ApplicationContext getspringContext(){
		
		return context;
	}
}
