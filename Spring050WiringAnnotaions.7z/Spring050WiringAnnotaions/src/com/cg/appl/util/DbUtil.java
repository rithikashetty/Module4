package com.cg.appl.util;

import java.sql.Connection;

public interface DbUtil {

	Connection getConnection();
}
