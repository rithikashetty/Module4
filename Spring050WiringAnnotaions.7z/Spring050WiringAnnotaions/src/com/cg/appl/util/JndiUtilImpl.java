package com.cg.appl.util;

import java.sql.Connection;

public class JndiUtilImpl implements DbUtil {

	public JndiUtilImpl(){
		System.out.println("In Constructor of Jndi Util");
		
	}
	@Override
	public Connection getConnection() {
		System.out.println("hii jndi get connection");
		return null;
	}

}
