package com.cg.appl.daos;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;

@Repository("entityDao")
public class EntityDao {

	private DbUtil dbUtil;
	public EntityDao() {
		
		System.out.println("In Constructor of Entitydao");
		
	}
/*	
	@Autowired
	@Qualifier("dbUtil2")*/
	@Resource(name="dbUtil1") //default behavior is byName and finds the name from propertyName
	public void setDbUtil(DbUtil dbUtil2){ //  dbUtil
		System.out.println("In setter of Entity Dao");
		this.dbUtil=dbUtil2;
		
		
	}

	public void getConnection(){
		dbUtil.getConnection();
		
	}
}
