package com.cg.appl.daos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;




import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.util.EntityManageUtil;
/*
 * 
 *Component: for evry class 
 * Service:For Service classes
 * repository:For dao class
 * Controller:for controller classes of spring MVc
 * RestController:To declare controller classes for publishing res
 * 
 * */
@Component("empDao")
public class EmpDaoImpl implements EmpEDao{
	
	private EntityManageUtil util;

	public EmpDaoImpl() {
		
		 System.out.println("In constructor of EmpDaoImpl");
	}
	
	@Autowired//autowiring by type
	@Qualifier("dbUtil")
	public void setUtil(EntityManageUtil util) {//util
		System.out.println("setUtil()");
		this.util = util;
	}


	@Override
	public Emp getEmpDetails() throws HrException {
		System.out.println("In getEmpDetails()");
		return null;
	}

}
