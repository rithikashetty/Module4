package com.cg.appl.daos;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface EmpEDao {
	
	Emp getEmpDetails() throws HrException;

}
