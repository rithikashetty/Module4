package com.cg.appl.entities;

import java.io.Serializable;







import javax.annotation.Generated;
/*import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.persistence.Transient;*/


/*@Entity(name="employee") //import jar files then import entity from javax persistence
@Table(name="EMP")//import from javax persistence.//if not written table then it takes class name as table name

@NamedQueries({
	@NamedQuery(name="qryEmpsOnSal",query="SELECT e from employee e where empSal between :from and :to"),
	@NamedQuery(name="qryAllEmps" , query="SELECT e from employee e"),
	@NamedQuery(name="qryEmpsComm",query="SELECT e from employee e WHERE comm is not null")//comm is property name not column name
	})
@SequenceGenerator(name="emp_generator",sequenceName="EMP_SEQ",allocationSize=1,initialValue=1)*/

public class Emp implements Serializable{
	private int empNo;
	private String empNm;
	private Float empSal;
	private Float comm;
	//private float totalSalary;
	
	//@Column(name="SAL+COMM")
	
/*//	@Transient*///
	
	public float getTotalSalary() {
		return getEmpSal()+(getComm()==null ?0: getComm());
	}
	
/*	public void setTotalSalary(float totalSalary) {
		this.totalSalary = totalSalary;
	}*/
	
	 //@Column(name="COMM")//
	public Float getComm() {
		return comm;
	}
	public void setComm(Float comm) {
		this.comm = comm;
	}
	
	
	//@Id //         //if not written then this error:No identifier specified for entity: com.cg.appl.entities.Emp
	//@GeneratedValue(generator="emp_generator",strategy=GenerationType.SEQUENCE)//
	
	public int getEmpNo() { //property name=empNo by default it takes property name as column name
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	//@Column(name="ENAME")// // if not written then it takes property name as column name //if property name and column name is same then no issues
	public String getEmpNm() { //empNm by default it takes property name as column name
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	//@Column(name="SAL")//
	public Float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + ", comm=" + comm + ", totalSalary=" + getTotalSalary()
				+ "]";
	}


	
}
