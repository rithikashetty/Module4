package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.util.SpringUtil;



public class TestLayering {

	public static void main(String[] args) {
		
		SpringUtil util = new SpringUtil();//classpath xml is created
		
		ApplicationContext ctx = util.getspringContext(); //object
		//System.out.println(ctx);
		System.out.println("******************");
		EmpServices empServices = ctx.getBean("empService",EmpServices.class);
		
		
		try {
			empServices.getEmpDetails();
		} catch (HrException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
