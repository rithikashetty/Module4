package com.cg.appl.services;

import javax.annotation.Resource;


import org.springframework.stereotype.Component;

import com.cg.appl.daos.EmpEDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

@Component("empService")
public class EmpServiceImpl implements EmpServices {
	private EmpEDao dao;

	
	public EmpServiceImpl() {
		System.out.println("In Constructor of EmpServiceImpl");
	}

	
	@Resource(name="empDao")
	public void setDao(EmpEDao dao) { //dao
		System.out.println("In Dao Impl");
		this.dao = dao;
	}



	@Override
	public Emp getEmpDetails() throws HrException {
		dao.getEmpDetails();
		return null;
	}

}
